package com.paymentservice;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.paymentservice.dao.TransactionRepository;
import com.paymentservice.dao.UserRepository;
import com.paymentservice.entity.User;
import com.paymentservice.service.TransactionService;
import com.paymentservice.service.UserService;

@RunWith(SpringRunner.class)
@SpringBootTest
class PaymentServiceApplicationTests {

	@Autowired
	private UserService userService;
	
	@Autowired
	private TransactionService transactionService;
	
	@MockBean
	private UserRepository userRepository;
	
	@MockBean
	private TransactionRepository TransactionRepository;
	
	
	// test for creating new user
	
//	@Test
//	public void saveUserTest() {
//		User user = new User(80,123490,111122223277777777,"Pema Khandu",
//				   8877665544,"Nagaland","Rupee",60000.0, Double,0.0,0.0);
//		when(userRepository.save(user)).thenReturn(user);
//		assertEquals(user, userService.saveUser(user));
//	}
//	
//	
//	(int iD, Integer userId, Long userCardNumber, String userName,
//			   Long contacttNo, String address, String currency, Double balance, Double totalCredits, Double totalDebits)
//	
	
//	@Test
//	public void getUserbyUserId() {
//		Integer userId = 12345;
//		when(TransactionRepository.getAllTransactionByUserId(1111222233335555))
//				.thenReturn(Stream.of().collect(Collectors.toList()));
//		assertEquals(1, transactionService.getAllTransactionByUserId(userId).size());
//	}
//	
	
//	@Test
//	public void saveUserTest() {
//		UserDTO user = new UserDTO(12349,1111222233335559,"Ganesh",9988776659,"Rupee",100000,0,0);
//		when(userRepository.save(user)).thenReturn(user);
//		assertEquals(user, userService.saveUser(user));
//	}
//	
//	User(int iD, Integer userId, Long userCardNumber, String userName,
//			   Long contacttNo, String address, String currency, Double balance, Double totalCredits, Double totalDebits)
//	
//	userId": "12349",
//    "userCardNumber": "1111222233335559",
//    "userName": "Ganesh",
//    "contacttNo": 9988776659,
//    "address": "Nagpur",
//    "currency": "Rupee",
//    "balance": 100000,
//    "totalCredits": 0,
//    "totalDebits": 0
//	
	
//	@Test
//	public void getUserBalanceTest() {
//		when(userRepository.getUserBalance()).thenReturn(Stream
//				.of(new User(), new User()).collect(Collectors.toList()));
//		assertEquals(2, userService.getUserBalance().size());
//	
//	}
	
	
//	@Test
//	public void getUsersTest() {
//		when(repository.findAll()).thenReturn(Stream
//				.of(new User(376, "Danile", 31, "USA"), new User(958, "Huy", 35, "UK")).collect(Collectors.toList()));
//		assertEquals(2, service.getUsers().size());
//}

}
